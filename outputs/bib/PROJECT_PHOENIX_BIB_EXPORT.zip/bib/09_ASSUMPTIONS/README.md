﻿Aannameslog en standaard projectdefaults.
